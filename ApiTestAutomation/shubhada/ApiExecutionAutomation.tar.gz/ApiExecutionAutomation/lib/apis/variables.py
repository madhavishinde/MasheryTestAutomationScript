ConfigFile = ''
#Id of campaign API
campaign_id = ""
#Id of ad API
ad_id = ""
#Id of audience API
audience_id  = ""
#Id of organization API
org_id  = ""
#Id of adsize API
adsize_id = ""
#Id of adtype API
adtype_id = ""
#Id of target API
target_id = ""
#Id of augmentor API
aug_id = ""
#Id of bidder API
bidder_id = ""
#Id of user API
user_id = ""
#URL of specific API
url_path = ""
#Upload_id of image uploaded
upload_id = ""
#Data to be send with post request
payload = {}
#To maintain total count of execution
total_count = 1
#To maintain count of successful execution
pass_count = 1
#To maintain count of failed execution
fail_count = 1
#Base url of APIs
base_url = ''
#Access token
token = u''
