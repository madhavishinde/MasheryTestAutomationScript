#Application's clientID required for OAuth2.0 authentication
client_id = 'zfupgaj4k7ashk2wx635zptm'
#Application's clientSecret required for OAuth2.0 authentication
client_secret = 'MAQb9HGK67Y2DevGVMNssTTx'
#Application's Authorization URL required for OAuth2.0 authentication
authorization_base_url = 'https://dspbuilder.rubiconproject.com/login'
#Application's token URL required for OAuth2.0 authentication
token_url = 'https://api.dspbuilder.rubiconproject.com/accesstoken'
#Application's Redirect URL required for OAuth2.0 authentication
redirect_uri = 'http://rubiconproject.mashery.com/io-docs/oauth2callback'
#Base url of all APIs
base_url = 'https://api.dspbuilder.rubiconproject.com'

#username of authorize user
user_email = "mchowla@rubiconproject.com"
#password of authorize user
user_password = "Mike2015!"
#Name of organization required while executing APIs
organization = "Gs lab"
#"Mealtime media"
