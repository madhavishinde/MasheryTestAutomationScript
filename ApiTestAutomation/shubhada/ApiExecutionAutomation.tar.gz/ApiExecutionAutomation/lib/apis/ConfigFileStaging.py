#Application's clientID required for OAuth2.0 authentication
client_id = 'kqraw62bm8efuh4dt5k2bc26'
#Application's clientSecret required for OAuth2.0 authentication
client_secret = 'Mgd3gCgSqBdm2uerUyX5Zr4y'
#Application's Authorization URL required for OAuth2.0 authentication
authorization_base_url = 'https://staging.dspbuilder.rubiconproject.com/login'
#Application's token URL required for OAuth2.0 authentication
token_url = 'https://api-staging.dspbuilder.rubiconproject.com/accesstoken'
#Application's Redirect URL required for OAuth2.0 authentication
redirect_uri = 'http://rubiconproject.mashery.com/io-docs/oauth2callback'
#Base url of all APIs
base_url = 'https://api-staging.dspbuilder.rubiconproject.com'


#username of authorize user
user_email = "rupali.kumar@gslab.com"
#"mchowla@rubiconproject.com"
#password of authorize user
user_password = "gslab2015"
#"Mike2015!"
#Name of organization required while executing APIs
organization = "New gs lab"
#"Mealtime media"
